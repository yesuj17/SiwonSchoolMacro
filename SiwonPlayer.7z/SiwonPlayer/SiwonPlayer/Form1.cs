﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace SiwonPlayer
{
    public partial class Form1 : Form, IMessageFilter
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern long SetCursorPos(int x, int y);

        //Mouse actions
        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        private uint savedMousePositionX = 0;
        private uint savedMousePositionY = 0;

        private string saveFile = @"C:\mydata.xml";

        BackgroundWorker worker = new BackgroundWorker();

        private bool _isStarted = false;
        
        public Form1()
        {
            InitializeComponent();
            InitData();

            Application.AddMessageFilter(this);
            this.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.RemoveMessageFilter(this);
        }

        public bool PreFilterMessage(ref Message m)
        {            
            if (m.Msg == 0x0100 && (Keys)m.WParam.ToInt32() == Keys.F2 )
                // &&ModifierKeys == Keys.Control)
            {
                Start();

                return true;
            }
            else if (m.Msg == 0x0100 && (Keys)m.WParam.ToInt32() == Keys.F3 )
                            // &&ModifierKeys == Keys.Control)            
            {
                Stop();
                return true;
            }

            return false;
        }

        public void DoMouseClick()
        {
            SetCursorPos((int)savedMousePositionX, (int)savedMousePositionY);
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, savedMousePositionX, savedMousePositionY, 0, 0 );            
        }

        private void worker_DoWork(object sender, DoWorkEventArgs args)
        {            
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                DoMouseClick();

                int secValue = Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value) * 60 ;

                dataGridView1.Rows[i].Selected = true;

                for (int j = 0; j < secValue; j++)
                {
                    if( _isStarted == false )
                    {
                        return;
                    }
                
                    System.Threading.Thread.Sleep(1000);
                }                                                               
            }
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs args)
        {
            dataGridView1.Enabled = true;
            button1.Enabled = true;
        }

        private void LoadXml()
        {
            if (File.Exists(saveFile))
            {
                DataSet ds = new DataSet();
                ds.ReadXml(saveFile);

                dataGridView1.DataSource = ds;
            }            
        }

        private void SaveXml()
        {
            DataSet ds = (DataSet)dataGridView1.DataSource;
            ds.WriteXml(saveFile);
        }

        private void Start()        
        {
            dataGridView1.Enabled = false;
            button1.Enabled = false;
            _isStarted = true;

            //SaveXml();

            savedMousePositionX = (uint)Cursor.Position.X;
            savedMousePositionY = (uint)Cursor.Position.Y;

            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);

            worker.RunWorkerAsync();
        }

        private void Stop()
        {
            _isStarted = false;         
        }

        private void InitData()
        {
            for (int i = 0; i < 60; i++)
            {
                comboBox1.Items.Add(i + 1);
            }

            comboBox1.SelectedItem = 5;
            
            dataGridView1.Columns.Add("No", "No");
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns.Add("간격(분)", "간격(분)");
            dataGridView1.Columns[1].Width = 210;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var value = comboBox1.SelectedItem;

            dataGridView1.Rows.Add( dataGridView1.Rows.Count, value.ToString());
        }
    }
}
